% Load data
load AUDneuronsim.mat

%% Create parameter structure for stimulus and format data
% Stimulus is a NT x nFreq spectrogram 
[NT,nFreq] = size(AUDstim);

nLags = 20; % number of time lags for estimating stimulus filters
params_stim = NIMcreate_stim_params([nLags nFreq],dt);

% Create 'Xmatrix'. Note that when the stimulus is a matrix it must be
% arranged so that time is in the first dimension. So if stim is a T x M
% matrix, Xstim will be a Tx(M*L) matrix where L is the number of time lags
% in the filter. The 2nd dimension of Xstim is arranged so that all lags
% for a given spatial dimension are chunked together (this is also how the
% stimulus filters are 'folded' into vectors.
Xstim = create_time_embedding( AUDstim, params_stim ); 

% Bin spikes into correct time resolution
Robs = histc( SIMspks, (0:(size(Xstim,1)-1))*params_stim.dt );

%% Fit a (regularized) GLM
% Select model parameters
mod_signs = [1]; % determines whether input is exc or sup (doesn't matter in the linear case)
NL_types = {'lin'}; % define subunit as linear 

% Create regularization parameter structure; in this case using spectrotemporal 
% smoothness and sparseness regularization on the filter coefs
params_reg = NIMcreate_reg_params( 'lambda_d2XT',40,'lambda_L1',100 ); 
% Note: can also separately specify different reg weights for freq and time:
%   params_reg = NIMcreate_reg_params( 'lambda_d2T',40,'lambda_d2X',60,'lambda_L1',50 ); 

silent = 0; %display model optimization iterations

% Initialize NIM (see 'help NIMinitialize_model' for more details about the model structure).
fit0 = NIMinitialize_model( params_stim, mod_signs, NL_types, params_reg ); 
% Fit stimulus filters
fit0 = NIMfit_filters( fit0, Robs, Xstim, [],[], silent ); 

% Check resulting S-T filter
figure; 
imagesc( reshape( fit0.mods(1).filtK, params_stim.stim_dims )' ); 

% Fit spiking nonlinearity
fit0 = NIMfit_logexp_spkNL( fit0, Robs, Xstim, [], 1 );

%% Fit NIM with 1 EXC and 1 INH threshold-linear subunits
mod_signs = [1 -1 ]; % make one exc & one inh component
NL_types = repmat({'threshlin'},1,2); %make all upstream NLs threshold-linear

% Initialize NIM
fit1 = NIMinitialize_model( params_stim, mod_signs, NL_types, params_reg ); 

% Fit stimulus filters -- note this will not converge for many random initializations, 
% which is more typical when there is excitation and inhibition
fit1 = NIMfit_filters( fit1, Robs, Xstim, [],[], silent ); 

% As a result, knowing the structure seen in the linear STRF, one can bias the initial guess
% to start closer to this model, and see if it works.
K0exc = fit0.mods(1).filtK;
K0inh = -fit0.mods(1).filtK;
K0exc(K0exc < 0) = 0;
K0inh(K0inh < 0) = 0;

fit1 = NIMinitialize_model( params_stim, mod_signs, NL_types, params_reg ); 
fit1.mods(1).filtK = K0exc;
fit1.mods(2).filtK = K0inh;

% Now fit with these initial conditions (LL will be much better)
fit1 = NIMfit_scale( fit1, Robs, Xstim, [], silent ); % quickly scales the mag of filters
fit1 = NIMfit_filters( fit1, Robs, Xstim, [],[], silent ); 

% Fit spiking nonlinearity
fit1 = NIMfit_logexp_spkNL( fit1, Robs, Xstim, [], 1 );

% Use built-in display function -- retry different initialization if not
% clear suppressive term
NIMdisplay_model( fit1 )

%% One can go further to see if there is nonlinear structure
% Convert upstream NLs to non-parametric functions, and fit
to_nonpar = 1:2; % which subunits to convert to tent-basis (nonparametric) upstream NLs
lambda_NLd2 = 1; % smoothness regularization on the tent-basis coefs

% Initializes the tent-basis representation
fit2 = NIMinitialize_upstreamNLs( fit1, Xstim, to_nonpar, lambda_NLd2 );

%% Now fit the upstream NLs
fit2 = NIMfit_upstreamNLs( fit2, Robs, Xstim, [],[],[], silent ); 
% Re-estimate filters and upstream NLs (iteratively)
fit2 = NIMfit_alt( fit2, Robs, Xstim, [], [], silent );
% it ends up looking threshold linear

%% Fit spiking nonlinearity
fit2 = NIMfit_logexp_spkNL( fit2, Robs, Xstim, [], 1 );

NIMdisplay_model( fit2 )  % display

%% Optimizing regularization: Can optimize using set-aside data
% Divide cross-validation data in two (set aside some for nested Xval)
NTxv = size(AUDstimXV,1);
AUDstimXV1 = AUDstimXV(floor(1:NTxv/2),:);
AUDstimXV2 = AUDstimXV((floor(NTxv/2)+1):end,:);

Xstim1 = create_time_embedding( AUDstimXV1, params_stim ); 
Xstim2 = create_time_embedding( AUDstimXV2, params_stim ); 

% Make cross-validation repeats
repindx = find(SIMspksXV < 0);
Nreps = length( repindx )
RobsXV = zeros(NTxv*fit0.stim_params.up_fac,Nreps);

repindx = [0 repindx'];
for n = 1:Nreps
	spks = SIMspksXV((repindx(n)+1):(repindx(n+1)-1));
	RobsXV(:,n) = histc(spks,(0:(NTxv*fit0.stim_params.up_fac-1))*fit0.stim_params.dt);
end

Robs1 = RobsXV(1:size(Xstim1,1),:);
Robs2 = RobsXV(size(Xstim1,1)+1:end,:);

%% Nested cross-validation of different regularizations
% Cycle through range of L1 for fit0
LLlist = [];
for reg = 0:10:100
	fit0R = NIMadjust_regularization(fit0,1,'lambda_L1',reg);
  fit0R = NIMfit_filters( fit0R, Robs, Xstim, [],[], 1 ); 

	% Fit spiking nonlinearity and check cross-validation
	fit0R = NIMfit_logexp_spkNL( fit0R, Robs, Xstim, [], 0 );
	LLs = NIMeval_LLreps( fit0R, Xstim1, Robs1 ); 
	LLlist(end+1) = median(LLs);
	fprintf( '  Reg =%3d: LL = %f\n', reg, LLlist(end) )
end
% Best regularization has no L1 (!)
fit0R1 = NIMadjust_regularization(fit0,1,'lambda_L1',0);
fit0R1 = NIMfit_filters( fit0R1, Robs, Xstim, [],[], 1 ); 
	
% Cycle through range of smoothness (Laplacian) reg for fit0
LLlist = [];
for reg = 0:5:50
	fit0R = NIMadjust_regularization(fit0R1,1,'lambda_d2XT',reg);
  fit0R = NIMfit_filters( fit0R, Robs, Xstim, [],[], 1 ); 

	% Fit spiking nonlinearity and check cross-validation
	fit0R = NIMfit_logexp_spkNL( fit0R, Robs, Xstim, [], 0 );
	LLs = NIMeval_LLreps( fit0R, Xstim1, Robs1 ); 
	LLlist(end+1) = median(LLs);
	fprintf( '  Reg =%3d: LL = %f\n', reg, LLlist(end) )
end
% Best regularization has XT as 20
fit0R = NIMadjust_regularization(fit0R1,1,'lambda_d2XT',20);
fit0R = NIMfit_filters( fit0R, Robs, Xstim, [],[], 1 ); 
fit0R = NIMfit_logexp_spkNL( fit0R, Robs, Xstim, [], 0 );

%% Regularization for NIM
LLlist = [];
for reg = 0:2:100
	fit1R = NIMadjust_regularization(fit1,1:2,'lambda_L1',reg);
  fit1R = NIMfit_filters( fit1R, Robs, Xstim, [],[], 1 ); 

	% Fit spiking nonlinearity and check cross-validation
	fit1R = NIMfit_logexp_spkNL( fit1R, Robs, Xstim, [], 0 );
	LLs = NIMeval_LLreps( fit1R, Xstim1, Robs1 ); 
	LLlist(end+1) = median(LLs);
	fprintf( '  Reg =%3d: LL = %f\n', reg, LLlist(end) )
end
% Best regularization has no L1 reg = 8 (changed the search to finer scale)
fit1R1 = NIMadjust_regularization(fit1,1:2,'lambda_L1',8);
fit1R1 = NIMfit_filters( fit1R1, Robs, Xstim, [],[], 1 ); 

LLlist = [];
for reg = 0:5:100
	fit1R = NIMadjust_regularization(fit1R1,1:2,'lambda_d2XT',reg);
  fit1R = NIMfit_filters( fit1R, Robs, Xstim, [],[], 1 ); 

	% Fit spiking nonlinearity and check cross-validation
	fit1R = NIMfit_logexp_spkNL( fit1R, Robs, Xstim, [], 0 );
	LLs = NIMeval_LLreps( fit1R, Xstim1, Robs1 ); 
	LLlist(end+1) = median(LLs);
	fprintf( '  Reg =%3d: LL = %f\n', reg, LLlist(end) )
end
% Best regularization has Reg = 15
fit1R = NIMadjust_regularization(fit1R1,1,'lambda_d2XT',15);
fit1R = NIMfit_filters( fit1R, Robs, Xstim, [],[], 1 ); 
fit1R = NIMfit_logexp_spkNL( fit1R, Robs, Xstim, [], 0 );

% Use same for fit2, because I'm lazy (and will agree)
fit2R = NIMadjust_regularization(fit2,1:2,'lambda_L1',8,'lambda_d2XT',15);
fit2R = NIMfit_filters( fit2R, Robs, Xstim, [],[], 1 ); 
fit2R = NIMfit_logexp_spkNL( fit2R, Robs, Xstim, [], 0 );


% Note could have done a 2-D search across reg parameters (and even checked
% more types as well as separately for each component) but wanted to give the 
% idea here. Also, the success of nested cross-validation (and specificity)
% will depend on the quality and amount of data.

%% Calculate final cross-validation (using untested data)
LL0 = NIMeval_LLreps( fit0, Xstim2, Robs2 ); 
LL0R = NIMeval_LLreps( fit0R, Xstim2, Robs2 ); 

LL1 = NIMeval_LLreps( fit1, Xstim2, Robs2 ); 
LL1R = NIMeval_LLreps( fit1R, Xstim2, Robs2 ); 

LL2 = NIMeval_LLreps( fit2, Xstim2, Robs2 ); 
LL2R = NIMeval_LLreps( fit2R, Xstim2, Robs2 ); 

% Note that the simulation (see 'AUDneuron') used simple threshold linear
% nonlinearities, but also a spike-history term at much higher resolution,
% which the fit2 is able to capture slightly better than fit1. However, the
% difference between these models does not appear to be statistically
% significant.
