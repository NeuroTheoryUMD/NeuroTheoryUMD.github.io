% Make sure NIMtoolbox is in the Matlab path
% Load data
load V1sim1d_data.mat

%% Create parameter structure for stimulus and format data
% Stimulus is a T x M matrix of 1-d binary white noise (M bars-wide, T time steps)
[NT,nPix] = size(stim);

nLags = 14; %number of time lags for estimating stimulus filters
params_stim = NIMcreate_stim_params([nLags nPix],dt);

% Create 'Xmatrix'. Note that when the stimulus is a matrix (in this case with spatial
% dimensions) it must be arranged so that time is in the first dimension. So if stim 
% is a T x M matrix, Xstim will be a Tx(M*L) matrix where L is the number of time lags
% in the filter. The 2nd dimension of Xstim is arranged so that all lags for a given 
% spatial dimension are chunked together (this is also how the stimulus filters are 
% 'folded' into vectors. 
Xstim = create_time_embedding(stim,params_stim); 

% Bin spikes into correct time resolution
Robs = histc(spiketimes,(0:(size(Xstim,1)-1))*params_stim.dt);

%% Fit a (regularized) GLM
% Select model parameters
mod_signs = [1]; % determines whether input is exc or sup (doesn't matter in the linear case)
NL_types = {'lin'}; % define subunit as linear 

% Create regularization parameter structure; in this case using spatiotemporal 
% smoothness and sparseness regularization on the filter coefs
params_reg = NIMcreate_reg_params( 'lambda_d2XT',10, 'lambda_L1',50 ); 
silent = 0; %display model optimization iterations

% Initialize NIM (see 'help NIMinitialize_model' for more details about the model structure).
fit0 = NIMinitialize_model( params_stim, mod_signs, NL_types, params_reg ); 
% Fit stimulus filters
fit0 = NIMfit_filters( fit0, Robs, Xstim, [],[], silent ); 

% Check resulting S-T filter
figure; colormap('gray')
imagesc( reshape( fit0.mods(1).filtK, params_stim.stim_dims ) ); 
% (not entirely obvious if this linear filter is useful.... try nonlinear anyway)

%% Fit NIM with 4 (EXC.) threshold-linear subunits
mod_signs = [1 1 1 1]; % make all four inputs excitatory 
NL_types = repmat({'threshlin'},1,4); %make all upstream NLs threshold-linear

% Initialize NIM
fit1 = NIMinitialize_model( params_stim, mod_signs, NL_types, params_reg ); 
% Fit stimulus filters
fit1 = NIMfit_filters( fit1, Robs, Xstim, [],[], silent ); 

% Use built-in display function
NIMdisplay_model( fit1, Xstim )

%% Convert upstream NLs to non-parametric functions, and fit
to_nonpar = 1:4; % which subunits to convert to tent-basis (nonparametric) upstream NLs
lambda_NLd2 = 500; % smoothness regularization on the tent-basis coefs

% Initializes the tent-basis representation
fit2 = NIMinitialize_upstreamNLs( fit1, Xstim, to_nonpar, lambda_NLd2 );

% Now fit the upstream NLs
fit2 = NIMfit_upstreamNLs( fit2, Robs, Xstim, [],[],[], silent ); 

%% Re-estimate the filters with the new NLS
fit3 = NIMfit_filters( fit2, Robs, Xstim, [],[], silent );

%% Fit quadratic model
mod_signs = [1 1 1 1]; % four excitatory inputs (doesn't matter for linear term)
NL_types = {'lin','quad','quad','quad'}; % define first subunit as linear and the other three as squared
params_reg = NIMcreate_reg_params( 'lambda_d2XT',10, 'lambda_L1', 1); % create regularization parameter structure
quad0 = NIMinitialize_model( params_stim, mod_signs, NL_types, params_reg ); % initialize Quad model
quad0 = NIMfit_filters( quad0, Robs, Xstim, [],[], silent ); % fit stimulus filters

%% REDUCED PLOTS OF MODELS 
%note, if you provide "Xstim" as a second input, you get soem more detailed plots
NIMdisplay_model(fit0); %GLM
NIMdisplay_model(fit3); %NIM
NIMdisplay_model(quad0); %GQM

%% Display four true filters (that the simulated data was generated with)
tax = (0:(nLags-1))*dt;
figure
for i = 1:4
    subplot(2,2,i)
    imagesc(1:nPix,tax,squeeze(true_filts(i,:,:)));
    set(gca,'ydir','normal');
    xlabel('Pixels')
    ylabel('Time lag')
    title(sprintf('Filter %d',i));
end
colormap(gray);
